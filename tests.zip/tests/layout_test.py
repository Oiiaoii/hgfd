# Bar found on other screen layouts? Mirror of Cv.kt: normal geometry (landscape, bar 0.77*h wide) vs the new relaxed pass.
import cv2, numpy as np, os
F=os.path.join(os.path.dirname(os.path.abspath(__file__)),'fixtures')+'/'
bar=cv2.imread(F+'3_minigame.png'); scene=cv2.imread(F+'4_failed.png')
# the picture was taken in the 'Ready!' state: paint the zone as it looks during a reel (two shades, no text)
bar=bar.copy(); bar[137:200,646:768]=(165,197,108); bar[137:200,768:890]=(47,143,52)
def hsvn(img):
    f=img.astype(np.float32); hi=[max(np.percentile(f[...,c],99.7),60.0) for c in range(3)]; ref=max(hi)
    for c in range(3): f[...,c]*=min(3.0,ref/hi[c])
    return cv2.cvtColor(np.clip(f,0,255).astype(np.uint8),cv2.COLOR_BGR2HSV), max(0.4,min(1.0,ref/255.0))
def masks(img):
    hsv,k=hsvn(img); H,S,V=[hsv[...,i].astype(int) for i in range(3)]; vf=int(100*k)
    blue=((H>=98)&(H<=135)&(S>=55)&(V>=vf)); anyz=((((H<=94)|(H>=141))&(S>=55)&(V>=vf))&~blue)
    dark=(cv2.cvtColor(img,cv2.COLOR_BGR2HSV)[...,2]<70)
    return blue,anyz,dark
def comps(anyz):
    m=anyz.astype(np.uint8)*255
    m=cv2.morphologyEx(m,cv2.MORPH_OPEN,cv2.getStructuringElement(cv2.MORPH_RECT,(3,max(5,m.shape[0]//150))))   # thin outlines and text strokes go
    m=cv2.morphologyEx(m,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_RECT,(5,3)))
    n,lab,st,_=cv2.connectedComponentsWithStats(m,8); return st[1:]
def extent(blue,anyz,dark,y,ch,zx,zw,W):
    ya=y+ch//4; yb=max(ya,y+ch-1-ch//4); rows=yb-ya+1
    cd,cb,ca=[m[ya:yb+1].sum(0) for m in (dark,blue,anyz)]
    ok=np.maximum(np.maximum(cd,cb),ca)*2>=rows
    mid=zx+zw//2; l=r=mid; gap=0; i=mid
    while i>=0:
        if ok[i]: l=i; gap=0
        else:
            gap+=1
            if gap>10: break
        i-=1
    r=mid; gap=0; i=mid
    while i<W:
        if ok[i]: r=i; gap=0
        else:
            gap+=1
            if gap>10: break
        i+=1
    return (l,r) if r-l>=3.5*zw else None
def find(img,relaxed):
    H,W=img.shape[:2]; blue,anyz,dark=masks(img); best=None; barL=W/2-.386*H; barR=W/2+.386*H
    for x,y,cw,ch,area in comps(anyz):
        if ch<3 or cw<2*ch: continue
        cx=x+cw/2; cy=y+ch/2
        if not relaxed:
            if not(.025*H<=ch<=.06*H) or cw<.02*W or cw>W/2 or area<cw*ch/2 or cx<barL or cx>barR or cy<.4*H or cy>.8*H: continue
        else:
            if not(.012*H<=ch<=.09*H) or cw<.02*W or cw>.6*W or area<cw*ch/2 or cx<.1*W or cx>.9*W or cy<.1*H or cy>.92*H: continue
            if extent(blue,anyz,dark,y,ch,x,cw,W) is None: continue
        if best is None or area>best[4]: best=(x,y,cw,ch,area)
    return best
def canvas(W,H,barw_frac,cy_frac):
    bg=cv2.resize(scene,(W,H)); bh=int(bar.shape[0]*(barw_frac*W/bar.shape[1])); bw=int(barw_frac*W)
    b=cv2.resize(bar,(bw,bh)); x0=(W-bw)//2; y0=int(cy_frac*H-bh/2); bg[y0:y0+bh,x0:x0+bw]=b
    zl=x0+int(647*bw/bar.shape[1]); zr=x0+int(889*bw/bar.shape[1]); return bg,(zl,zr,y0+bh//2)
print('%-34s %-18s %-18s'%('layout','normal geometry','relaxed pass'))
for name,(W,H,bf,cf) in {'landscape 2340x1080, bar 0.77h wide':(2340,1080,.772*1080/2340,.62),'landscape, bar 0.6h wide':(2340,1080,.6*1080/2340,.55),
    'portrait 1080x2400, bar 0.85w':(1080,2400,.85,.55),'portrait 1080x2400, bar 0.6w':(1080,2400,.6,.30),'tablet 1600x2560':(2560,1600,.55,.7)}.items():
    img,(zl,zr,zy)=canvas(W,H,bf,cf)
    res=[]
    for rel in (False,True):
        f=find(img,rel)
        if f is None: res.append('NOT FOUND')
        else: res.append('ok (zone %d..%d)'%(f[0],f[0]+f[2]) if abs(f[0]-zl)<=.02*W and abs(f[0]+f[2]-zr)<=.02*W else 'WRONG %s'%(f[:4],))
    print('%-34s %-18s %-18s'%(name,*res))
