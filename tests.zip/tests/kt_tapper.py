# Faithful Python port of Tapper.kt (v2.2) + the reel simulator, to look for the "spam after 1-2 minigames" bug.
import numpy as np
from reel_sim import Physics, Capture

class KtTapper:
    def __init__(s, gain0, drain0, delay0=35.0, hold=35.0, gap=70.0, clamp=None):
        s.taps=[]; s.zh=[]; s.gain=max(5,gain0); s.drain=max(10,drain0); s.delay=min(140,max(5,delay0))
        s.hold=hold; s.minGap=max(gap,hold+20); s.pts=0; s.pp=0.0; s.acc=0.0; s.zc=0; s.zw=0; s.zv=0.0; s.have=False
        s.lastFire=0; s.dtEma=25.0; s.quietT=0; s.quietP=0.0; s.g0=gain0; s.clamp=clamp
    def inflight(s): return [t for t in s.taps if t['st']==0]
    def see(s,capT,tip,haveTip,zc,zw):
        s.zc=zc; s.zw=zw; s.have=True
        s.zh.append((capT,zc)); s.zh=[z for z in s.zh if capT-z[0]<=400]
        old=[z for z in s.zh if 100<=capT-z[0]<=260]
        if old:
            v=(zc-old[0][1])/((capT-old[0][0])/1000.0); s.zv=0.0 if abs(v)<25 else 0.6*s.zv+0.4*v
        if not haveTip: return
        if s.pts!=0 and capT>s.pts:
            dt=(capT-s.pts)/1000.0
            if dt<0.3:
                s.dtEma=0.9*s.dtEma+0.1*dt*1000
                r=tip-(s.pp-s.drain*dt); s.acc+=r
                fl=s.inflight()
                while fl and s.acc>=0.6*s.gain and fl[0]['fire']<capT:
                    t=fl.pop(0); t['st']=1
                    lat=capT-t['fire']-0.5*s.dtEma
                    if 5<lat<200: s.delay=0.95*s.delay+0.05*lat
                    if not fl and s.acc<1.6*s.gain:
                        s.gain=0.96*s.gain+0.04*min(max(s.acc,0.5*s.gain),1.6*s.gain)
                        if s.clamp: s.gain=min(max(s.gain,s.clamp[0]*s.g0),s.clamp[1]*s.g0)
                    s.acc-=s.gain
                s.acc=min(max(s.acc,-0.5*s.gain),2.5*s.gain) if fl else 0.0
                lim=max(220.0,3.0*s.delay)
                for t in fl:
                    if capT-t['fire']>lim: t['st']=2
                if not s.inflight():
                    if s.quietT!=0 and s.quietT<=capT:
                        qd=(capT-s.quietT)/1000.0
                        if qd>=0.08:
                            d=(s.quietP-tip)/qd
                            if 0.5*s.drain<d<1.6*s.drain: s.drain=0.96*s.drain+0.04*d
                            s.quietT=capT; s.quietP=tip
                    else: s.quietT=capT; s.quietP=tip
                else: s.quietT=0
        s.pts=capT; s.pp=tip
        s.taps=[t for t in s.taps if not(t['st']!=0 and t['fire']<capT-1500)]
    def cancelled(s,fire):
        for t in s.taps:
            if t['fire']==fire and t['st']==0: t['st']=2
    def want(s,now,gap):
        if s.pts==0 or not s.have or now-s.pts>300: return False
        if now-s.lastFire<max(gap,s.minGap): return False
        n=len(s.inflight()); hz=now+s.delay+s.hold/2
        pT=s.pp-s.drain*(hz-s.pts)/1000+s.gain*n
        zT=s.zc+max(-s.zw,min(s.zw,s.zv*(hz-s.pts)/1000))
        return pT<zT-0.5*s.gain
    def commit(s,now): s.lastFire=now; s.taps.append(dict(fire=now,st=0))

def run(ctrl, secs=40, seed=1, zw=80, zv=0.0, L=45.0, fps=45, cancel=0.03, verbose=False):
    rng=np.random.RandomState(seed); ph=Physics(rng,zw=zw,zv=zv,L=L,cancel=cancel); cap=Capture(rng,fps=fps,subpx=True)
    ins=tot=taps=0; win=[]; pend=[]; gains=[]
    for ms in range(int(secs*1000)):
        ph.step(1.0); o=cap.tick(ph)
        if o:
            _,ts,tip,zc,zw_,hidden=o; ctrl.see(ts,tip,not hidden,zc,zw_)
        for f,at in list(pend):
            if ph.t>=at: ctrl.cancelled(f); pend.remove((f,at))
        if ms%4==0 and ctrl.want(ph.t,70):
            ctrl.commit(ph.t); n0=len(ph.pending); ph.tap(ph.t); taps+=1; win.append(ph.t)
            if len(ph.pending)==n0: pend.append((ph.t,ph.t+60))
        if ms>3000: tot+=1; ins+=ph.inzone()
        if ms%5000==0: gains.append(int(ctrl.gain))
    mx=max((sum(1 for w in win if t-1000<w<=t) for t in win),default=0)
    return 100*ins/tot, taps/secs, mx, gains

if __name__=='__main__':
    G,D=58.0,215.0
    for seed in (1,2,3):
        r=run(KtTapper(G,D),secs=60,seed=seed)
        print('seed',seed,'in-zone %.1f%%  taps/s %.1f  max taps in 1s %d  learned gain every 5 s:'%r[:3],r[3])
