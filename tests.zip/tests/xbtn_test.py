# X button recognition on the WHITE strokes only (background independent), tested across scales and backgrounds.
import cv2, numpy as np, os
F=os.path.join(os.path.dirname(os.path.abspath(__file__)),'fixtures')+'/'
im=[cv2.imread(F+n) for n in ('1_fish.png','2_exit.png','3_minigame.png','4_failed.png','5_caught.png')]
X4=im[3][60:140,1125:1210]; X5=im[4][75:160,1140:1215]
def white(g, thr=215): 
    m=(g>=thr).astype(np.float32)*255.0
    return cv2.GaussianBlur(m,(3,3),0)
def tpl_from(img):
    g=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY); m=white(g)
    ys,xs=np.where(m>100); y0,y1,x0,x1=ys.min(),ys.max(),xs.min(),xs.max()
    pad=4; return m[max(0,y0-pad):y1+pad+1,max(0,x0-pad):x1+pad+1]
T4=tpl_from(X4); T5=tpl_from(X5)
print('template sizes',T4.shape,T5.shape)
def balanced_white(img):
    """colour balance the top part of the screen (channels to the same white level), then keep only the white strokes.
    The brightness threshold follows the picture's own white level, so a dim screen or a night filter still shows the X."""
    top=img[:int(img.shape[0]*0.6)].astype(np.float32)
    hi=[max(np.percentile(top[...,c],99.7),60.0) for c in range(3)]; ref=max(hi)
    for c in range(3): top[...,c]*=min(3.0,ref/hi[c])
    g=cv2.cvtColor(np.clip(top,0,255).astype(np.uint8),cv2.COLOR_BGR2GRAY)
    thr=max(120.0,214.0*min(1.0,ref/255.0))
    return cv2.GaussianBlur((g>=thr).astype(np.float32)*255.0,(3,3),0)
def find(img,tpls,lo=0.05,hi=1.2):
    m=balanced_white(img); best=(0,None,0)
    def at(T,s):
        t=cv2.resize(T,(max(1,int(T.shape[1]*s)),max(1,int(T.shape[0]*s))),interpolation=cv2.INTER_AREA)
        if t.shape[0]>=10 and t.shape[0]<m.shape[0] and t.shape[1]<m.shape[1] and t.std()>1:
            r=cv2.matchTemplate(m,t,cv2.TM_CCOEFF_NORMED); _,mx,_,loc=cv2.minMaxLoc(r); return mx,(loc[0]+t.shape[1]//2,loc[1]+t.shape[0]//2)
        return 0,None
    for T in tpls:
        s=lo; top=(0,None,0)
        while s<=hi:
            mx,p=at(T,s)
            if mx>top[0]: top=(mx,p,s)
            s*=1.14
        if top[2]:
            for f in np.arange(0.92,1.081,0.02):
                mx,p=at(T,top[2]*f)
                if mx>top[0]: top=(mx,p,top[2]*f)
        if top[0]>best[0]: best=top
    return best
print('--- same-picture and cross-background')
for n,img in enumerate(im,1):
    b=find(img,[T4,T5]); print(n,'score %.2f at %s scale %.2f'%(b[0],b[1],b[2]))
print('--- other sizes (phone shrinks the picture), expected position = scaled X centre')
for k in (0.5,0.3,0.2):
    for n in (3,4):   # images 4 and 5 (index 3,4)
        img=im[n]; sm=cv2.resize(img,None,fx=k,fy=k,interpolation=cv2.INTER_AREA)
        b=find(sm,[T4,T5]); print('shrink %.1f image %d: score %.2f'%(k,n+1,b[0]),b[1])
