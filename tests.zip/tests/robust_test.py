# Does the bar reading survive what real phones do to the picture? (dim screen, night/warm filter, blur, JPEG, different bar size)
import cv2, numpy as np, os
F=os.path.join(os.path.dirname(os.path.abspath(__file__)),'fixtures')+'/'
base=cv2.imread(F+'3_minigame.png')
EXP=(647,889)   # zone as drawn

def wp(img):
    """colour balance: scale channels to the same white level (fixes night / tint filters), brightness is NOT changed"""
    f=img.astype(np.float32); hi=[max(np.percentile(f[...,c],99.7),60.0) for c in range(3)]; ref=max(hi)
    out=f.copy()
    for c in range(3): out[...,c]=f[...,c]*min(3.0,ref/hi[c])
    return np.clip(out,0,255).astype(np.uint8), ref/255.0

def read(img, S_ZONE=70, V_ZONE=110, S_BLUE=70, V_BLUE=120, rel=False, norm=False):
    k=1.0
    if norm: img,k=wp(img)
    hsv=cv2.cvtColor(img,cv2.COLOR_BGR2HSV); H,S,V=[hsv[...,i].astype(int) for i in range(3)]
    if rel:   # brightness-relative floors, from the picture's own white level
        kk=max(0.4,min(1.0,k)); V_ZONE=int(100*kk); V_BLUE=int(100*kk)
    blue=(H>=98)&(H<=135)&(S>=S_BLUE)&(V>=V_BLUE)
    anyz=(((H<=94)|(H>=141))&(S>=S_ZONE)&(V>=V_ZONE))&~blue
    rows=np.where(blue.sum(1)>img.shape[1]*.05)[0]
    if len(rows)==0: return None
    y0,y1=rows.min(),rows.max()
    def run(m):
        col=m[y0:y1+1].mean(0)>.35; idx=np.where(col)[0]
        if len(idx)==0: return None
        g=np.where(np.diff(idx)>12)[0]; st=np.r_[idx[0],idx[g+1]]; en=np.r_[idx[g],idx[-1]]; i=np.argmax(en-st); return int(st[i]),int(en[i])
    return run(blue),run(anyz)

def tint(img,r=1.0,g=1.0,b=1.0): 
    f=img.astype(np.float32); f[...,2]*=r; f[...,1]*=g; f[...,0]*=b; return np.clip(f,0,255).astype(np.uint8)
cases={
 'as drawn':base,
 'brightness 70%':tint(base,.7,.7,.7),
 'brightness 50%':tint(base,.5,.5,.5),
 'brightness 40%':tint(base,.4,.4,.4),
 'night filter (warm)':tint(base,1.0,.85,.55),
 'strong night filter':tint(base,1.0,.7,.35),
 'blur 5x5':cv2.GaussianBlur(base,(5,5),0),
 'JPEG q40':cv2.imdecode(cv2.imencode('.jpg',base,[cv2.IMWRITE_JPEG_QUALITY,40])[1],1),
 'half size':cv2.resize(base,None,fx=.5,fy=.5,interpolation=cv2.INTER_AREA),
}
def score(r,scale=1.0):
    if r is None or r[1] is None: return 'ZONE LOST'
    z=r[1]; ok=abs(z[0]-EXP[0]*scale)<=8*scale+4 and abs(z[1]-EXP[1]*scale)<=8*scale+4
    return ('OK   ' if ok else 'WRONG')+' zone %s blue %s'%(z,r[0])
for mode,kw in (('v2.3 fixed floors',dict()),('relative floors + lower S',dict(S_ZONE=55,S_BLUE=55,rel=True)),('white-patch colour normalisation + relative floors',dict(S_ZONE=55,S_BLUE=55,rel=True,norm=True))):
    print('==',mode)
    for n,im in cases.items():
        print('  %-22s %s'%(n,score(read(im,**kw),.5 if n=='half size' else 1.0)))
