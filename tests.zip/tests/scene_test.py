# v2.3 desktop check of the new screen recognition (same rules as Scene.kt and Cv.anyMask), run on the 5 screenshots.
import cv2, numpy as np, os
F = os.path.join(os.path.dirname(__file__), 'fixtures') + '/'
im = [cv2.imread(F + n) for n in ('1_fish.png', '2_exit.png', '3_minigame.png', '4_failed.png', '5_caught.png')]
tpl = {'fish': im[0][372:476, 60:672], 'exit': im[1][368:468, 75:678]}
import io, contextlib
with contextlib.redirect_stdout(io.StringIO()):
    import xbtn_test as XT

def best(g, t, accept):
    """coarse sweep (steps of 14%), then a fine search +-8% in 2% steps around the best size"""
    tg = cv2.cvtColor(t, cv2.COLOR_BGR2GRAY) if t.ndim == 3 else t; top = (0, None)
    def at(s):
        tt = cv2.resize(tg, (int(tg.shape[1]*s), int(tg.shape[0]*s)), interpolation=cv2.INTER_AREA)
        if 10 <= tt.shape[0] < g.shape[0] and 10 <= tt.shape[1] < g.shape[1]:
            return cv2.minMaxLoc(cv2.matchTemplate(g, tt, cv2.TM_CCOEFF_NORMED))[1]
        return 0
    s = 0.05
    while s <= 1.2:
        m = at(s)
        if m > top[0]: top = (m, s)
        s *= 1.14
    if top[1]:
        base = top[1]
        for f in np.arange(0.92, 1.081, 0.02):
            m = at(base*f)
            if m > top[0]: top = (m, base*f)
    return top

def scene(img):
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    x = XT.find(img, [XT.T4, XT.T5])[0]
    f = best(g, tpl['fish'], .82)[0]; e = best(g, tpl['exit'], .82)[0]
    if x >= .80: return 'X'
    if f >= .82 and f > e: return 'FISH'
    if e >= .82: return 'EXIT'
    return 'NONE'

def zone(img):
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV); H, S, V = [hsv[..., i].astype(int) for i in range(3)]
    blue = (H >= 98) & (H <= 135) & (S >= 70) & (V >= 120)
    anyz = (((H <= 94) | (H >= 141)) & (S >= 70) & (V >= 110)) & ~blue
    rows = np.where(blue.sum(1) > img.shape[1]*.05)[0]; y0, y1 = rows.min(), rows.max()
    col = anyz[y0:y1+1].mean(0) > .35; idx = np.where(col)[0]
    gaps = np.where(np.diff(idx) > 12)[0]
    st = np.r_[idx[0], idx[gaps+1]]; en = np.r_[idx[gaps], idx[-1]]; i = np.argmax(en-st)
    return int(st[i]), int(en[i])

want = ['FISH', 'EXIT', 'NONE', 'X', 'X']
ok = True
for n, (img, w) in enumerate(zip(im, want), 1):
    r = scene(img); print(n, r, 'OK' if r == w else 'WRONG'); ok &= (r == w)
print('zone as drawn  :', zone(im[2]), '(expected about 646..889)')
# recolour the zone to other colours: the bar must still be found at the same place
hsv0 = cv2.cvtColor(im[2], cv2.COLOR_BGR2HSV)
for name, hue in [('orange', 12), ('yellow', 28), ('red', 2), ('pink', 165), ('purple', 150), ('cyan', 88)]:
    h = hsv0.copy(); zs = (h[..., 0] >= 55) & (h[..., 0] <= 85) & (h[..., 1] >= 70) & (h[..., 2] >= 110)
    h[..., 0][zs] = hue; z = zone(cv2.cvtColor(h, cv2.COLOR_HSV2BGR))
    good = abs(z[0]-646) <= 6 and abs(z[1]-889) <= 6; ok &= good
    print(f'zone {name:7s}:', z, 'OK' if good else 'WRONG')
print('ALL OK' if ok else 'FAILED')
if __name__ == '__main__': raise SystemExit(0 if ok else 1)
