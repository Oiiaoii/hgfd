# Edge tapper (new in 2.3 "script-like" tapping): ONE tap when the blue fill reaches the left edge of the zone,
# one more when it falls back to the edge again. Spams a little only while the zone runs away from the fill.
import numpy as np
from reel_sim import Physics, Capture
import kt_tapper as K
from drift_test import SmoothPhysics

class Edge:
    RAMP = 60.0
    def __init__(s, G, D, L=50.0, hold=35.0, minGap=80.0):
        s.G=G; s.D=D; s.L=L; s.hold=hold; s.minGap=max(minGap,hold+20)
        s.taps=[]; s.last=-1e9; s.ts=None; s.tip=0; s.zc=0; s.zw=0; s.zh=[]; s.zv=0.0; s.gain=G
    def see(s,capT,tip,have,zc,zw):
        s.zc=zc; s.zw=zw
        s.zh.append((capT,zc)); s.zh=[z for z in s.zh if capT-z[0]<=400]
        old=[z for z in s.zh if 100<=capT-z[0]<=260]
        if old:
            v=(zc-old[0][1])/((capT-old[0][0])/1000.0); s.zv=0.0 if abs(v)<25 else 0.6*s.zv+0.4*v
        if have: s.ts=capT; s.tip=tip
        s.taps=[t for t in s.taps if t>capT-1500]
    def cancelled(s,f):
        if f in s.taps: s.taps.remove(f)
    def want(s,now,gap=0):
        if s.ts is None or now-s.ts>300: return False
        T=now+s.L+s.RAMP/2
        unseen=0.0
        for f in s.taps:
            vis=min(1.0,max(0.0,(s.ts-f-s.L)/s.RAMP)); unseen+=1.0-vis
        pT=s.tip-s.D*(T-s.ts)/1000.0+s.G*unseen
        zl=s.zc-s.zw/2+max(-s.zw,min(s.zw,s.zv*(T-s.ts)/1000.0))
        e=min(0.12*s.zw,0.5*max(0.0,s.zw-s.G))
        thr=zl+e
        emergency = pT < zl-0.5*s.G
        refr = s.minGap if emergency else max(s.minGap,0.5*s.G/s.D*1000)
        if pT<=thr and now-s.last>=refr:
            return True
        return False
    def commit(s,now): s.last=now; s.taps.append(now)

def run(ctrl,phys,secs=40,seed=1,zw=80,zv=0.0,L=45.0,cancel=0.03,fps=45):
    rng=np.random.RandomState(seed); ph=phys(rng,zw=zw,zv=zv,L=L,cancel=cancel); cap=Capture(rng,fps=fps,subpx=True)
    ins=tot=taps=0; win=[]; pend=[]; lowest=0
    for ms in range(int(secs*1000)):
        ph.step(1.0); o=cap.tick(ph)
        if o: _,ts,tip,zc,zw_,h=o; ctrl.see(ts,tip,not h,zc,zw_)
        for f,at in list(pend):
            if ph.t>=at: ctrl.cancelled(f); pend.remove((f,at))
        if ms%4==0 and ctrl.want(ph.t,70):
            ctrl.commit(ph.t); n0=len(getattr(ph,'ramps',ph.pending)); ph.tap(ph.t); taps+=1; win.append(ph.t)
            if len(getattr(ph,'ramps',ph.pending))==n0: pend.append((ph.t,ph.t+60))
        if ms>3000: tot+=1; ins+=ph.inzone()
    mx=max((sum(1 for w in win if t-1000<w<=t) for t in win),default=0)
    return 100*ins/tot,taps/secs,mx

if __name__=='__main__':
    G,D=58.0,215.0
    cases=[("jump lift, zone 80",Physics,dict(zw=80)),("smooth lift, zone 80",SmoothPhysics,dict(zw=80)),
           ("smooth, moving zone 120px/s",SmoothPhysics,dict(zw=80,zv=120)),("smooth, delay 90 ms",SmoothPhysics,dict(zw=80,L=90)),
           ("smooth, zone 60",SmoothPhysics,dict(zw=60)),("smooth, 20 fps",SmoothPhysics,dict(zw=80,fps=20)),("smooth, 15% cancelled",SmoothPhysics,dict(zw=80,cancel=0.15))]
    print("%-30s %-26s %-26s"%("case","v2.2 ledger in%/taps/max1s","Edge in%/taps/max1s"))
    for n,ph,kw in cases:
        a=np.mean([run(K.KtTapper(G,D),ph,seed=s,**kw) for s in range(1,4)],0)
        b=np.mean([run(Edge(G,D),ph,seed=s,**kw) for s in range(1,4)],0)
        print("%-30s %5.1f / %4.1f / %4.1f        %5.1f / %4.1f / %4.1f"%(n,*a,*b))
