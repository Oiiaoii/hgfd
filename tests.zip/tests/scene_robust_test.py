# Fish / Exit / X recognition under brightness, night filter, blur, JPEG and phone-size changes.
import io, contextlib, cv2, numpy as np
with contextlib.redirect_stdout(io.StringIO()):
    import scene_test as S, xbtn_test as XT
im=S.im
def tint(img,r=1,g=1,b=1):
    f=img.astype(np.float32); f[...,2]*=r; f[...,1]*=g; f[...,0]*=b; return np.clip(f,0,255).astype(np.uint8)
T={'plain':lambda x:x,'dim 50%':lambda x:tint(x,.5,.5,.5),'night filter':lambda x:tint(x,1,.7,.35),'blur 5x5':lambda x:cv2.GaussianBlur(x,(5,5),0),
   'JPEG q40':lambda x:cv2.imdecode(cv2.imencode('.jpg',x,[cv2.IMWRITE_JPEG_QUALITY,40])[1],1),'shrink 0.4':lambda x:cv2.resize(x,None,fx=.4,fy=.4,interpolation=cv2.INTER_AREA),
   'shrink 0.25':lambda x:cv2.resize(x,None,fx=.25,fy=.25,interpolation=cv2.INTER_AREA)}
want=['FISH','EXIT','NONE','X','X']; bad=0
print('%-14s'%'transform',*['img%d(%s)'%(i+1,w) for i,w in enumerate(want)])
for n,f in T.items():
    row=[]
    for img,w in zip(im,want):
        r=S.scene(f(img)); ok=(r==w); bad+=0 if ok else 1; row.append(('ok' if ok else 'WRONG:'+r))
    print('%-14s'%n,*['%-14s'%x for x in row])
print('failures:',bad); raise SystemExit(1 if bad else 0)
