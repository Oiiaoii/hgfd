# Checks the behaviour asked for, on a zone that wanders:
#   zone goes LEFT (fill is now above it)   -> no taps until the fill has drained back into the zone
#   zone goes RIGHT (fill is now below it)  -> quick taps until the fill is in the zone
#   fill in the zone                        -> one tap each time it reaches the left edge
# and looks for a "stops after the first tap" stall, with a wrong assumed tap delay and with missed lifts.
import io, contextlib, numpy as np
with contextlib.redirect_stdout(io.StringIO()):
    import edge_sim as E
    from drift_test import SmoothPhysics
from reel_sim import Capture

class Wander(SmoothPhysics):
    """zone path: still, then a jump LEFT 160 px, still, then RIGHT 220 px, then slow drift, ..."""
    def step(s,dt=1.0):
        super().step(dt)
        t=s.t/1000.0
        s.zc=1200.0+ (0 if t<4 else -160*min(1,(t-4)/0.4)) + (0 if t<8 else 380*min(1,(t-8)/0.5)) + (0 if t<12 else -260*min(1,(t-12)/0.5)) + (0 if t<16 else 120*np.sin((t-16)*1.2))
    def __init__(s,*a,**k): super().__init__(*a,**k); s.zv=0.0

class EdgeRule(E.Edge):
    """rush_mode 'old': spam only while the predicted fill is more than half a lift below the zone edge.
       rush_mode 'new': spam until the predicted fill is IN the zone (at or right of its left edge)."""
    def __init__(s,*a,rush_mode='new',**k): super().__init__(*a,**k); s.mode=rush_mode
    def want(s,now,gap=0):
        if s.ts is None or now-s.ts>300: return False
        T=now+s.L+s.RAMP/2; unseen=0.0
        for f in s.taps: unseen+=1.0-min(1.0,max(0.0,(s.ts-f-s.L)/s.RAMP))
        pT=s.tip-s.D*(T-s.ts)/1000.0+s.G*unseen
        zl=s.zc-s.zw/2+max(-s.zw,min(s.zw,s.zv*(T-s.ts)/1000.0)); e=min(0.12*s.zw,0.5*max(0.0,s.zw-s.G))
        rush = pT<(zl if s.mode=='new' else zl-0.5*s.G)
        refr = s.minGap if rush else max(s.minGap,0.5*s.G/s.D*1000)
        return pT<=zl+e and now-s.last>=refr

def run(ctrl,seed=1,secs=22,L_true=45.0,cancel=0.03,start_fill=300.0):
    rng=np.random.RandomState(seed); ph=Wander(rng,zw=80,zv=0,L=L_true,cancel=cancel); ph.p=start_fill; cap=Capture(rng,fps=45,subpx=True)
    taps=[]; ins=tot=0; above_taps=0; stall=0.0; run_stall=0.0; last_tap=-1e9; first3=[]
    for ms in range(int(secs*1000)):
        ph.step(1.0); o=cap.tick(ph)
        if o: _,ts,tip,zc,zw_,h=o; ctrl.see(ts,tip,not h,zc,zw_)
        if ms%4==0 and ctrl.want(ph.t,70):
            ctrl.commit(ph.t); ph.tap(ph.t); taps.append(ph.t)
            if ph.p>ph.zc+ph.zw/2+10: above_taps+=1       # tap while the fill is clearly above the zone
            last_tap=ph.t
            if ph.t<3000: first3.append(ph.t)
        below = ph.p < ph.zc-ph.zw/2-10
        if below: 
            run_stall = ph.t-last_tap if last_tap>0 else ph.t
            stall=max(stall,run_stall)
        if ms>3000: tot+=1; ins+=ph.inzone()
    gaps=np.diff([0]+first3) if first3 else [9999]
    return dict(inz=100*ins/tot, taps_s=len(taps)/secs, above=above_taps, worst_stall=stall, first3=len(first3), first_gap=max(gaps))

G,D=58.0,215.0
def avg(f,**kw):
    rs=[run(f(),seed=s,**kw) for s in (1,2,3,4)]; return {k:np.mean([r[k] for r in rs]) for k in rs[0]}
print('%-44s %6s %6s %7s %9s %7s'%('case','in-zone%','taps/s','taps while above','worst stall below (ms)','first-3 s taps / longest gap'))
for lab,L_true,L_assumed,cancel in [('delay as assumed (45/50 ms)',45,50,.03),('real delay 90, assumed 50',90,50,.03),('real delay 140, assumed 50',140,50,.03),('real delay 45, assumed 110',45,110,.03),('25% of taps lost',45,50,.25)]:
    for mode in ('old','new'):
        r=avg(lambda: EdgeRule(G,D,L=L_assumed,rush_mode=mode),L_true=L_true,cancel=cancel)
        print('%-30s rush:%-4s %6.1f %6.1f %9.1f %14.0f %12d / %4.0f ms'%(lab,mode,r['inz'],r['taps_s'],r['above'],r['worst_stall'],r['first3'],r['first_gap']))

# ---- self-measuring tap delay (isolated taps only) ----
class EdgeCal(EdgeRule):
    def __init__(s,*a,**k): super().__init__(*a,**k); s.pend=[]; s.hist=[]; s.nlat=0
    def see(s,capT,tip,have,zc,zw):
        super().see(capT,tip,have,zc,zw)
        if not have: return
        # baseline: last observation before each tap
        for f in list(s.pend):
            t0,tip0,fire=f['t0'],f['tip0'],f['fire']
            if capT<=fire: continue
            exp=tip0-s.D*(capT-t0)/1000.0
            lift=tip-exp
            if lift>=0.5*s.G:
                iso=all((o<fire-150) or (o>fire+s.L+s.RAMP+100) for o in s.taps if o!=fire)
                if iso and capT-fire<400:
                    sample=capT-fire-0.5*s.RAMP-20    # half of the lift visible, minus half a ramp and the frame wait = delay
                    s.nlat+=1; s.L=min(160.0,max(20.0,0.8*s.L+0.2*sample if s.nlat>1 else sample))
                s.pend.remove(f)
            elif capT-fire>400: s.pend.remove(f)
        s.hist=(s.hist+[(capT,tip)])[-40:]
    def commit(s,now):
        super().commit(now)
        prev=[h for h in s.hist if h[0]<=now]
        if prev: s.pend.append(dict(t0=prev[-1][0],tip0=prev[-1][1],fire=now))
print()
print('self-measured delay (EdgeCal), same cases, rush:new')
for lab,L_true,L_assumed,cancel in [('real delay 45, assumed 50',45,50,.03),('real delay 90, assumed 50',90,50,.03),('real delay 140, assumed 50',140,50,.03),('real delay 45, assumed 110',45,110,.03),('25% of taps lost',45,50,.25)]:
    r=avg(lambda: EdgeCal(G,D,L=L_assumed,rush_mode='new'),L_true=L_true,cancel=cancel)
    print('%-30s %6.1f %6.1f %9.1f %14.0f %12d / %4.0f ms'%(lab,r['inz'],r['taps_s'],r['above'],r['worst_stall'],r['first3'],r['first_gap']))
