import numpy as np
from reel_sim import Physics
import kt_tapper as K

class SmoothPhysics(Physics):
    def __init__(s,*a,**k):
        super().__init__(*a,**k); s.ramps=[]
    """the fill rises smoothly over RAMP ms after the tap lands (like an animation), not as one jump"""
    RAMP=90.0
    def step(s,dt=1.0):
        s.t+=dt; s.p=max(0.0,s.p-s.D*dt/1000.0); keep=[]
        for lt,a,done in getattr(s,'ramps',[]):
            part=a*dt/s.RAMP
            if s.t>=lt and done<a: s.p+=part; keep.append((lt,a,done+part))
            elif s.t<lt: keep.append((lt,a,done))
        s.ramps=keep
        s.zc+=s.zv*dt/1000.0
        if s.zc<900 or s.zc>1500: s.zv=-s.zv
    def tap(s,t):
        if s.rng.rand()<s.cancel: return
        s.ramps=getattr(s,'ramps',[])+[(t+s.L+s.rng.randn()*s.Ljit,s.G*(1+0.04*s.rng.randn()),0.0)]

def run(ctrl,secs=60,seed=1,zw=80,zv=0.0,L=45.0):
    from reel_sim import Capture
    rng=np.random.RandomState(seed); ph=SmoothPhysics(rng,zw=zw,zv=zv,L=L); cap=Capture(rng,fps=45,subpx=True)
    ins=tot=taps=0; win=[]; g=[]
    for ms in range(secs*1000):
        ph.step(1.0); o=cap.tick(ph)
        if o: _,ts,tip,zc,zw_,h=o; ctrl.see(ts,tip,not h,zc,zw_)
        if ms%4==0 and ctrl.want(ph.t,70):
            ctrl.commit(ph.t); ph.tap(ph.t); taps+=1; win.append(ph.t)
        if ms>3000: tot+=1; ins+=ph.inzone()
        if ms%5000==0: g.append(int(ctrl.gain))
    mx=max((sum(1 for w in win if t-1000<w<=t) for t in win),default=0)
    return 100*ins/tot,taps/secs,mx,g
for seed in (1,2):
    r=run(K.KtTapper(58.0,215.0),seed=seed); print('v2.2 ledger, smooth lift: in-zone %.1f%% taps/s %.1f max/1s %d gain:'%r[:3],r[3])
